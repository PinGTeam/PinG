`make test` will run unit test cases for the MySQL PinG database

# Coded by Richard Hamm and Zach Sirotto
