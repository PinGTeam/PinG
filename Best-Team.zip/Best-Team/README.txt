﻿PinG Milestone 5 README.txt
----------------------------------------


Concrete instructions on how to compile:
-----------------------------------------------------
Mobile Android Application:
- Download the PinGv2 folder from the android source-code directory.
- Once downloaded, open Android Studio.
- Once open, click File->Open project.
- Open the PinGv2 folder and select the Android Studio project file.
- Once project is open, wait for all files to sync with gradle build.
- Code is now ready to build and run.


Libraries Used for Android Build:
- Okhttp3 Version 3.4.1
- GSON Version 2.6.2
- Google Play Services 9.8.0
- JUnit Testing Framework Version 4.12


Packages Needed for Android Build:
- Android SDK Tools Version 25.2.2
- Android SDK Platform-tools Version 25
- Android SDK Build-tools Versions 23.0.1 - 24.0.3
- Android 7.1.1 (API 25)
- Android 6.0 (API 23)
- Android 5.1.1 (API 22)
- Extras > Google APIs by Google Inc, Android API 24, revision 1
- Extras > Android Support Repository Version 39
- Extras > Google Play Services Version 37
- Extras > Google Repo Version 38
- Extras > Google USB Driver Version 11
- Extras > Intel x86 Emulator Accelerator (HAXM installer) Version 6.0.4 [if you have an intel processor, otherwise download the AMD version]


Android Version Needed for Build:
- Minimum Android 5.1 Lollipop OS












Mobile iOS Application:
- Install Xcode Version 8.1 or later from either:
* Xcode Developer Documentation Website: https://developer.apple.com/xcode/
* Mac App Store Download: https://itunes.apple.com/us/app/xcode/id49779983
- Follow this Filepath to find the IOS PinG application and its associated source code files: PinG/Source-Code/IOS/PinG, then open the file titled: “PinG.xcodeproj”.
- Code is compiled as it is run through XCode. Provided below are further instruction on how to compile the source code.
- The application is built every time the “play” button is pressed. The simulator will then open automatically, and the application will run. 




Concrete instructions on how to run our code:
------------------------------------------------------------
Mobile Android Application:
- Once code syncs and project has been built; plug in an android phone or create an emulator.
- NOTE: If using phone to test, go to applications on phone and manually grant PinG access to location.
- Once an emulator or phone is connected, click on “run code” or press alt+shift+f10.
- Run code on device.
- Application will install and automatically boot up.






Mobile iOS Application:
- Follow this Filepath to find the IOS PinG application and its associated source code files: PinG/Source-Code/IOS/PinG, then open the file titled: “PinG.xcodeproj”
- Make sure the simulator is set to an iOS simulator. Change this option in the uppermost left hand area by clicking the button directly to the right of word “Ping”.
- Click on the Play Button located at top left of the Xcode window to Build the source code and run PinG on an iOS simulator. The App is now ready to be simulated.
- Enable location services for the PinG app. After the iOS simulator begins running, manually simulate a location by clicking the outlined compass arrow icon on the very bottom of the Xcode window. Select a location and then proceed to use the application in the simulator. 
 - Feel free to use the default.gpx file to simulate Strozier library, or any other location that is an option to host your location.
 - If this is the first time running on the specified environment, the application will request Location access permissions.
- The application is now ready for use. 






________________


Concrete commands on how to run the unit test cases:
------------------------------------------------------
Back-end Tests:
- The file requestmngr_tests.py contains the flask tests for the middle tier communication   between the database and the app on both Android and iOS
 
 Tests:


1. Database is empty [EmptyDatabaseTestCase]
      - Tests getallevents and getnearevents


2. Database with some data [NonEmptyDatabaseTestCase]
      - Tests getallevents and getnearevents


3. Adding with "adduser" and checking if users have been added [EmptyDatabaseWithAddUserTestCase]
      - Tests adduser


4. Adding with "addevent" and checking if event has been added [EmptyDatabaseWithAddEventTestCase]
      - Tests adduser, addevent, getallevents and getnearevents


5. Creating an event and checking its blank attendance list with getattendance
[EmptyAttendanceTestCase]
    - Tests adduser, addevent, and getattendance.


6. Addings attendees with “attend” and toggling it with the same command, while viewing the results with getattendance
[EmptyAttendanceTableWithAddTestCase]
    - Tests adduser, addevent, getattendnace, and attend, as well as the toggling nature of attend.


7. Adding severals attendees to an event with “attend” on multiple users, and then viewing them with getattendance
[EmptyAttendanceTableWithMultipleAddsTestCase]
    - Tests adduser, addevent, and getattendance with attend. Views the results of the array with getattendance.


8. Removing several attendees from an event with “attend” on multiple users
[RemovingFromAttendanceTableTestCase]
    - Tests attend and getattendance. 


9. Uses the alternate route for getnearevents by using getnearevents_alt
[EmptyDatabaseGetNear_AltTestCase]
    - Tests getnearevents_alt


10. Uses addevent’s alternate route with addevent_alt
[EmptyDatabaseWithAdds_AltTestCase]
    -  Tests adduser and addevent_alt


11. Uses editevent’s alternate route with editevent_alt
[NonEmptyDatabaseEditEvent_AltTestCase]
    - Tests editevent_alt




Assuming all dependencies installed and “requestmngr.py” in your directory. 
To run tests, type in the command line "python requestmngr_tests.py".
      


Android Unit Tests:
1. Open up PinGv2 project file in Android Studio.
2. Navigate to java > com.example.jorge.pingv2
3. Right click UnitTests.java file.
4. Press Run Unit Tests in the dropdown box or press the hotkey ctrl+shift+f10


iOS Unit Tests:
1. Open PinG.xcodeproj
2. Make sure the simulator is set to an iOS simulator. Change this option in the uppermost left hand area by clicking the button directly to the right of word “Ping”
3. Access the Project Navigator field on the left side by clicking on the blue folder icon. 
4. In the Project Navigator field, within the folder titled “PinG” there are two folders that contain the source code for testing: PinGTests and PinGUITests.
5. Click on the file titled “PinGTests.swift”, the file will then open in the middle view field. 
6. Beside each Unit Test function, there should be a small play button to the left of the line numbers. Clicking the play button beside the class “PinGTests” will perform each test case in the file. Clicking each individual play button performs each individual Unit Test associated with the function, and a notification will then be displayed to denote whether the test succeeds or does not.
7. In order to test the UI, click on the file titled “PinGUITests.swift”, then click on the play button beside the class “PinGUITests” in the middle view field. The simulator will then open and perform the tests.






________________


Acceptance Tests
--------------------------------------------------------------------------------------------------------------
Mobile Android Application Acceptance Tests:
* When the application icon is clicked on the phone or emulator, the application will load
            and display a user login screen.
* The login screen shows the application name at the top center(with current version number attached to name), and 2 text fields that prompt the user for a userID, and password.
* The user has the option to click on “sign up” instead of login.
* Upon clicking “sign up”, the user is prompted with fields to create a new account with PinG.
* If an email already exists and the user tries signing up with it, they will be prompted with a message telling them that.
* If a userName already exists and the user tries signing up with it, they will be prompted with a message telling them that.
* If an email and userName already exists and the user tries signing up with it, they will be prompted with a message telling them that.
* Upon successful account creation, the user will be brought back to the login screen.
* When the user clicks logIn, all their logIn data is sent to the database and they are assigned their unique userID.
* If a user enters nothing for the fields, an error will be displayed.
* Once the user has successfully logged into PinG, the user is redirected to the map activity.
* The user can scroll around, tilt, rotate, and zoom in/out on the map.
* At the top right of the screen there is a current location button that will reset the screen and center it on the user’s location.
* The map will refresh events upon new event creations and when the user moves locations.
* On the bottom right of the screen there is the ping button that when clicked, brings up the Event Creation Activity.
* In the Event Information screen, the user is presented with 4 text fields and 4 input fields: The user can fill this out as they so wish
* If Time Start and Time End of Event is not given in the following format: YYYY-DD-MM
* HH:MM:SS the database will save the time is None, otherwise it will store correctly.
* Once all the information is filled out, the user may click CANCEL to avoid placing a ping at current location, or click SUBMIT to place a ping at their current location:
* When the ping is placed, its information is sent to the database for storage.
* Once a ping has been placed on the map, a user can click on the ping to pull up a custom event window that will display to the user that ping’s name, start time, end time, description, and name of the event host.
* If the user is the host of the event, they will be allowed to edit the event, otherwise you can only view the details of the event.
* In order to edit the event after clicking on a ping, edit the event details accordingly and then press the edit button with a pencil on it, at the top right of the window. This will prompt the user if they are sure if they would like to edit the event or not. Upon clicking yes, the new data is sent to the server.
* In order to view your user profile, you can click the user profile button at the top left of the toolbar, or you can choose to swipe right from the left-hand side of the screen.
* In order to logout of the application, click the menu button at the top right of the PinG screen, and then press logout.


Mobile iOS Application Acceptance Tests:
* The mobile application is ran from XCode by building the code by clicking the Play button on the top left of the XCode application window.
* One the application is built, it will be deployed onto either the simulator or a physical iPhone, depending on the Build Target. 
* The app will automatically launch on the target. Once built, the app can be accessed from the Home screen by tapping on the application icon. 
* The login screen shows the application logo at the top center, with two fields below it prompting the user for their Username and Password.
* The user can click Login to login to the application, or they can create an account by clicking on Sign Up 
* If the username/password were typed incorrectly, or the user does not exist in the database, the user would be prompted with an error message below the Sign Up button.
* The user would be presented with the New User View controller after tapping on Sign Up. This view contains 6 fields: First Name, Last Name, Username, E-mail, Password, and Confirm Password.
* Client-side checks are made before the information in the fields are sent to the server.
   * All fields must have information in them.
   * The email must be a valid email address
   * The information presented in the Password and Confirm password fields must match.
* Once the client-side checks are satisfied, a POST request is made to the server to perform server side verification checks
   * The username must not exist on the database
   * The e-mail must not exist on the database
* Any incorrect fields would be highlighted red, with a corresponding error message.
* Once the user successfully creates a PinG account, the user is brought back to the login screen.
* The user can choose not to create an account by going back to the previous view from the navigation bar.
* Once the user logs in with the correct information, the user is brought to the Map View screen. 
* The user can scroll around the map, zoom in and out.
* The user will be able to see pings from a 25 mile radius, where the position of the user is the center.
* The map will be refreshed when a user creates an event and if the user changes his/her location.
* At the top of the map is the Navigation Bar.
   * At the far left is the “Profile” page button, to the right of it is the “View event” button, Then the title of the application(PinG!), a “Refresh” button and an “Add Event” button.
* The “Profile” page button redirects the user to his/her profile. The profile page consists of an Image at the top center, the user’s full name below it and then the user’s username right under his/her name. At the bottom of the screen, on the center, there is a logout button.
* When the logout button is clicked, the app will logout the user and the login page will be presented to the user.
* At the top left corner of the Profile page there is a button that reads “< PinG!” that goes back to the map view.
* When a user clicks on a ping on the map, an annotation will appear on top of it. The annotation consists of the event title, the owner’s name, the description of the event, the starting and ending times and if the user is attending, a green checkmark.
* When the annotation is visible on the screen, the “View event” button is enabled.
* Clicking on the “View event” button will take the user to the Event Information view.
   *  On this view, there is a field that contains the event name and the owner’s name, below it is a field that has the event description.
   *  Under it is the starting time and the ending time of the event. 
   * Below that is a field that reads “Attending?” with a slider, when enabled it means that the user is going to attend the event.
   *  Below is the “View Attendees” field with the amount of attendees, when clicked on it another view will open that will display the name of all the attendees of the event. 
   * From there you can go back to the event view window by clicking on the top left corner’s button.
* If a user is the owner of the event, he/she will have an “edit” button on the top right corner of the screen. It will 4 fields that can be updated. 
   * The first one is the event’s title, and the user can click there and change the name of the event.
   *  Below is the event description which the user can edit as well.
   * Then the starting time field is below it. When the user clicks on it a date picker will slide down below it. The user can change the hour the event starts. The end time is changed exactly the same.
   * After all the changes are done there is a “Save Changes” button at the bottom of the screen, when clicked it will update the event with all the changes made and the data is sent to the server.
* The button to the right of “View Event” is “Refresh”. When clicked the map will be centered to the user’s position and a new request for “get events” is sent to the server.
* The far left button on the Navigation Bar is the “Add event” button. When clicked, the user is redirected to the Add event view.
* The Add Event view consists of 2 fields and 2 date pickers. The first field is for the Event Name, the user can make sure it is for event name because there is a placeholder that reads “Event Name”. The same goes for Event Description. The first date picker reads “From” on the left side, and it the date picker for the starting time of the event. When clicked it will slide down a date picker which the user can select a starting time for the event. Below it is the ending time date picker, which reads “To” on the far left. When clicked it also slides down a date picker for the user to select the ending time.