-- Establishes TestUser variables
SET @UserName = 'TestUser' + day(current_date())+ minute(current_time());
SET @Firstname = 'Test';
SET @LastName = 'User';

-- Start a transaction.
BEGIN;

-- Plans # of tests 
SELECT tap.plan( 2 );

-- InsertUser and suppress returned UserID
CALL InsertUser_NoReturn(@UserName, @FirstName, @LastName);

-- Retrieve userid of test user
SET @userid = (SELECT userid from users where username = @UserName and FirstName = @FirstName and LastName = @LastName);

-- Tests if user is inserted
SELECT tap.ok(exists(SELECT * from users where username = @UserName and FirstName = @FirstName and LastName = @LastName),'Tests if user is inserted.');

-- Retrieve number of users to determine uniqueness.
CALL InsertUser_NoReturn(@UserName, @FirstName, @LastName);
SET @userCount = (select Count(userid) from users where username = @UserName and FirstName = @FirstName and LastName = @LastName);

-- Tests that user is not duplicated upon additional insertions
SELECT tap.eq(@userCount, 1, 'Tests uniqueness amongst usernames.');

-- Display test has been completed 
SELECT '\n+--------------------------+';
SELECT '|SQL Unit Test 1 Completed!|';
SELECT '+--------------------------+';

-- Finish the tests and clean up.
CALL tap.finish();
SELECT '';

-- Run unit test 2 
SELECT 'Testing InsertEvent()';
SELECT '---------------------';

-- Setup parameters for event insertion
SET @EventName = 'TestEvent' + day(current_date()) + minute(current_time());
SET @EVENTDesc = 'Test Desc' + day(current_date()) + minute(current_time());
SET @pointlong = RAND(3) * -180;
SET @pointlat = RAND(3) * -90;

-- Plans # of tests 
SELECT tap.plan( 1 );

-- INSERT EVENT AS TESTUSER
CALL InsertEvent(@userid, @EventName, @pointlat, @pointlong, SYSDATE(), @EVENTDesc); 

-- Test if event is successfully inserted into the database.
SELECT tap.ok(exists(SELECT * from eventtable where eventName = @EventName and latitude = @pointlat and longitude = @pointlong),'Tests if event is inserted.');

-- Insert 10 events in 10 different locations




-- Display test has been completed 
SELECT '\n+--------------------------+';
SELECT '|SQL Unit Test 2 Completed!|';
SELECT '+--------------------------+';


-- Finish the tests and clean up.
CALL tap.finish();




ROLLBACK;


